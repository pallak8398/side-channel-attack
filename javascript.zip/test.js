var i = 0;
var lineArr;

function reader(){
	document.getElementById("sb_form_q").value = lineArr[i];
	console.log(lineArr[i]);
	i++;
}


function readTextFile(file)
{
    var rawFile = new XMLHttpRequest();
    rawFile.open("GET", file, true);
    rawFile.onreadystatechange = function ()
    {
        if(rawFile.readyState === 4)
        {
            if(rawFile.status === 200 || rawFile.status == 0)
            {
                var allText = rawFile.responseText;
                console.log(allText);
                lineArr = allText.split('\n');
                setInterval(reader, 5000);
                //alert(allText);
                //window.alert(1+2);
            }
        }
    }
    rawFile.send(null);
}

readTextFile("file:///home/dell/Desktop/SEM_5/Mini_Project/1letterwords.txt");