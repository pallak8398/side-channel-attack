var i = 0;
//var lineArr;
//var file1 = "https://github.com/gillsimu/sideattack_project/blob/master/1letterwords.txt";

function readTextFile(file)
{
    var rawFile = new XMLHttpRequest();
    rawFile.responseType = 'text';
    
    rawFile.onreadystatechange = function ()
    {	alert('abc2');
        if(rawFile.readyState === 4)
        {alert('abc');
            if(rawFile.status == 200 || rawFile.status == 0)
            {
            	alert('abc3');
                var allText = this.responseText;
                //lineArr = allText[0];
                console.log(allText);
                console.log(rawFile.response);
            }
        }
    };
    rawFile.open("GET", file, true);
    rawFile.send(null);
}

var file = "file:///home/dell/Desktop/SEM_5/Mini_Project/1letterwords.txt";
readTextFile(file);