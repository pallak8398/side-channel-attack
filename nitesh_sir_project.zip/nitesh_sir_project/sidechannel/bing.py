'''
['', 'DATA_LAYER', '__class__', '__delattr__', '__dict__', '__dir__', '__doc__', '__format__', '__getattr__', '__getattribute__', '__getstate__', '__hash__', '__init__', '__module__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__setattr__', '__setstate__', '__sizeof__', '__str__', '__subclasshook__', '__weakref__', '_all_fields', '_field_prefix', '_get_all_field_lines', '_get_all_fields_with_alternates', '_get_field_or_layer_repr', '_get_field_repr', '_layer_name', '_sanitize_field_name', '_ws_expert', '_ws_expert_group', '_ws_expert_message', '_ws_expert_severity', 'accept', 'accept_encoding', 'accept_language', 'chat', 'connection', 'cookie', 'cookie_pair', 'field_names', 'get', 'get_field', 'get_field_by_showname', 'get_field_value', 'host', 'layer_name', 'pretty_print', 'raw_mode', 'referer', 'request', 'request_full_uri', 'request_line', 'request_method', 'request_number', 'request_uri', 'request_uri_path', 'request_uri_query', 'request_uri_query_parameter', 'request_version', 'user_agent']
'''
import pyshark

cap = pyshark.LiveCapture(interface = 'en1')
for pkt in cap.sniff_continuously():
	try:
		source = pkt.ip.src
		protocol = pkt.highest_layer
		host = pkt.http.host
		if(source == '192.168.0.107' and protocol == 'HTTP'):
			host = pkt.http.host
			if(host == 'www.bing.com'):
				print('SENT')
				print(len(pkt.http.request_uri_query.split('&')[2].split('=')[1]))
			#print(pkt.http.request_uri_query.split('&')[2].split('=')[1])
		elif(source == '172.31.1.4' and protocol == 'DATA-TEXT-LINES'):
			if(pkt.http.set_cookie.split('=')[-1] == 'bing.com'):
				print('RECEIVED')
				print(pkt.http.content_length)				
	except AttributeError as e:
		#print("passing...")
		pass



