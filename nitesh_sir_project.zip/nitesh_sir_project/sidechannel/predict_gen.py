file  = open("predict_1.tab", "a")
file.write("String"+"\t"+"Length\n")
for i in range(450, 550):
	file.write("?"+"\t"+str(i)+"\n")
file.close()

file  = open("predict_2.tab", "a")
file.write("String"+"\t"+"Length\n")
for i in range(550, 650):
	file.write("?"+"\t"+str(i)+"\n")
file.close()

file  = open("predict_3.tab", "a")
file.write("String"+"\t"+"Length\n")
for i in range(650, 750):
	file.write("?"+"\t"+str(i)+"\n")
file.close()

file  = open("predict_4.tab", "a")
file.write("String"+"\t"+"Length\n")
for i in range(750, 850):
	file.write("?"+"\t"+str(i)+"\n")
file.close()

file  = open("predict_5.tab", "a")
file.write("String"+"\t"+"Length\n")
for i in range(850, 950):
	file.write("?"+"\t"+str(i)+"\n")
file.close()

file  = open("predict_6.tab", "a")
file.write("String"+"\t"+"Length\n")
for i in range(950, 1050):
	file.write("?"+"\t"+str(i)+"\n")
file.close()

file  = open("predict_7.tab", "a")
file.write("String"+"\t"+"Length\n")
for i in range(1050, 1150):
	file.write("?"+"\t"+str(i)+"\n")
file.close()

file  = open("predict_8.tab", "a")
file.write("String"+"\t"+"Length\n")
for i in range(1150, 1250):
	file.write("?"+"\t"+str(i)+"\n")
file.close()

file  = open("predict_9.tab", "a")
file.write("String"+"\t"+"Length\n")
for i in range(1250, 1350):
	file.write("?"+"\t"+str(i)+"\n")
file.close()