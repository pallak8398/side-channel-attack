'''
['', 'DATA_LAYER', '__class__', '__delattr__', '__dict__', '__dir__', '__doc__', '__format__', '__getattr__', '__getattribute__', '__getstate__', '__hash__', '__init__', '__module__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__setattr__', '__setstate__', '__sizeof__', '__str__', '__subclasshook__', '__weakref__', '_all_fields', '_field_prefix', '_get_all_field_lines', '_get_all_fields_with_alternates', '_get_field_or_layer_repr', '_get_field_repr', '_layer_name', '_sanitize_field_name', '_ws_expert', '_ws_expert_group', '_ws_expert_message', '_ws_expert_severity', 'accept', 'accept_encoding', 'accept_language', 'chat', 'connection', 'cookie', 'cookie_pair', 'field_names', 'get', 'get_field', 'get_field_by_showname', 'get_field_value', 'host', 'layer_name', 'pretty_print', 'raw_mode', 'referer', 'request', 'request_full_uri', 'request_line', 'request_method', 'request_number', 'request_uri', 'request_uri_path', 'request_uri_query', 'request_uri_query_parameter', 'request_version', 'user_agent']
'''
import pyshark

class bing:
	#cap = None
	data_map = {'538': 'a', '544': 'b', '548': 'c', '547':'ab', '522': 'ac', '549':'ad', '514':'ae', '567':'ba'}
	def __init__(self, ip_add):
		filt = 'src net ' + str(ip_add)
		self.cap = pyshark.LiveCapture(interface = 'en1', bpf_filter = filt)

	def predict(lenn):
		if(data_map.has_key(lenn)):
			return data_map[lenn]
		else:
			minn = 999999
			ret_key = ""
			for key in data_key.keys():
				tmp = abs(int(lenn) - int(key))
				if(tmp < minn):
					minn = tmp
					ret_key = key
			return ret_key
	def run(self, ip_add):
		for pkt in self.cap.sniff_continuously():
			try:
				source = pkt.ip.src
				protocol = pkt.highest_layer
				host = pkt.http.host
				if(source == ip_add and host == 'www.bing.com'):
					#predict(len(pkt.http.request_uri_query.split('&')[2].split('=')[1]))
					print(pkt.length)
					print(len(pkt.http.request_uri_query.split('&')[2].split('=')[1]))
					print(pkt.http.request_uri_query.split('&')[2].split('=')[1])
			except AttributeError as e:
				#print("passing...")
				pass

ip_add = "192.168.43.124"
b = bing(ip_add)
b.run(ip_add)