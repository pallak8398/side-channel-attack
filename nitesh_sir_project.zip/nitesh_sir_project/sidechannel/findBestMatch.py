from sets import Set
import pyshark
length = 0
ch = ''
len2 = 0
len3 = 0
cap = pyshark.LiveCapture(interface = 'en1')
for pkt in cap.sniff_continuously():
	try:
		source = pkt.ip.src
		protocol = pkt.highest_layer
		#host = pkt.http.host
		if(source == '192.168.0.106' and protocol == 'HTTP'):
			host = pkt.http.host
			if(host == 'www.bing.com'):
				print('SENT')
				length = len(pkt.http.request_uri_query.split('&')[2].split('=')[1])
				print(length)
				#print(pkt.http.request_uri_query.split('&')[2].split('=')[1])
				if(length == 1):
					ch = pkt.http.request_uri_query.split('&')[2].split('=')[1]
		elif(source == '172.31.1.4' and protocol == 'DATA-TEXT-LINES'):
			if(pkt.http.set_cookie.split('=')[-1] == 'bing.com'):
				print('RECEIVED')
				print(pkt.http.content_length)
				if(length == 2):
					len2 = int(pkt.http.content_length)	
				elif(length == 3):
					len3 = int(pkt.http.content_length)
					print('BREAKING..')
					break			
	except AttributeError as e:
		pass

print(ch)
print(len2)
print(len3)
fp = open("map2_final.txt", "r+")
m = {}
st = set()
while True:
	str = fp.readline()
	if str == "":
		break
	s, val = str.split(' ')
	s = s.strip()
	val = int(val)
	if s[0:1] == ch:
		m[s] = abs(val - len2)
fp.close()
fp = open('map3_final.txt', 'r+')

while True:
	str = fp.readline()
	if str == "":
		break
	s, val = str.split(' ')
	s = s.strip()
	val = int(val)
	if s[0:2] in m:
		val2 = abs(val -len3) + m[s[0:2]]
		st.add((val2, s))
		if len(st) > 10:
			st.remove(max(st))

while st:
	b = min(st)
	print(b)
	st.remove(b)