/*
 * This is a JavaScript Scratchpad.
 *
 * Enter some JavaScript, then Right Click or choose from the Execute Menu:
 * 1. Run to evaluate the selected text (Cmd-R),
 * 2. Inspect to bring up an Object Inspector on the result (Cmd-I), or,
 * 3. Display to insert the result in a comment after the selection. (Cmd-L)
 */
function sleepFor( sleepDuration ){
    var now = new Date().getTime();
    while(new Date().getTime() < now + sleepDuration){ /* do nothing */ } 
}
var val = "a";
var i;
for(i = 0; i < 26; i++) {
  var val2 = "a" + String.fromCharCode(val.charCodeAt(0)+i);
  document.getElementById("sb_form_q").value = val2;
  sleepFor(1000);
}

/*
Exception: ReferenceError: char is not defined
@Scratchpad/1:13:7
*/
/*
Exception: ReferenceError: int is not defined
@Scratchpad/1:13:7
*/
/*
Exception: ReferenceError: number is not defined
@Scratchpad/1:13:7
*/

var jq = document.createElement('script');
jq.src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js";
document.getElementsByTagName('head')[0].appendChild(jq);
// ... give time for script to load, then type (or see below for non wait option)
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js">
$('#sb_form_q').keyup(function(){
    $("#sb_form_q").val($("#sb_form_q").val()+"a");
});
Object { 0: <input#sb_form_q.b_searchbox>, length: 1, context: HTMLDocument → /, selector: "#sb_form_q" }
function a(){
    $("#sb_form_q").val($("#sb_form_q").val()+"a");
    var e = $.Event('keyup');
    $("#sb_form_q").trigger(e);
}
undefined
setInterval(a, 10000);
1863